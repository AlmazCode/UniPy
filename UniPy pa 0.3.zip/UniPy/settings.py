import pygame

pygame.init()

# enigine settings
version = "pre-alpha 0.3"

# create engine display
win = pygame.display.set_mode((0, 0), pygame.HWSURFACE | pygame.DOUBLEBUF, vsync = 0)
clock = pygame.time.Clock()
pygame.display.set_caption(f"UniPy {version}")

# start display settings
width = win.get_width()
height = win.get_height()
AppWidth = width
AppHeight = height - 80
fps = 60

# app display
winApp = pygame.Surface((AppWidth, AppHeight))

# other settings
lastSelectionObject = None
lastPressedInput = None
IsRightMouseButton = False
scrollForceShowdown = 4
lastSelectionObjectClass = None
isRenameFile = False
isRenameProject = False
isCreateObject = False
isSelector = False
isConsole = False
lastSelectorContent = None

# returns the path to the project
def GPTP():
	return f"./projects/{projects[projectIdx]}/"

LPBFS = None #last pressed button for selector

layer = -1

"""
-1 choose project
0 - editor
1 - app
2 - conductor
3 - project assets conductor
"""

# for project system
modules = []
projects = []
files = []
projectIdx = 0
projectSize = (0,0)
MHFS = []
MHFU = []

# game settings
GBGSC = (255, 255, 255) # game bg start color
GBGC = GBGSC # game bg color

# UI settings
uiTColor = (255, 255, 255) # engine ui text color
uiBgColor = (60, 60, 60) # engine bg color
uiBC = (130, 130, 130) # ui buttons color
uiBPC = (100, 100, 100) # ui buttons pressed color
uiIC = (150, 150, 150) # ui inputs color
uiIPC = (100, 100, 100) # ui inputs pressed color
uiSOHBGC = (50, 50, 50) # ui selection object hierarchy bg color
uiSOHTC = (255, 255, 255) # ui selection object hierarchy text color
uiPSEC = (0, 160, 255) # ui project selected elem color
uiSOHSEC = (0, 160, 255) # ui selection object hierarchy selected elem color
uiCC = (50, 50, 50) # ui conductor color
uiSOHC = (100, 100, 100) # ui selection object hierarchy color
uiPEC = (100, 100, 100) # ui project elem color
uiCEC = (100, 100, 100) # ui conductor elem color
uiEIC = (255, 255, 255) # ui engine images color
uiCBC = (60, 60, 60) # ui console background color
uiCTC = (255, 255, 255) # ui conductor text color
uiPMTC = (255, 255, 255) # ui project manager text color
uiITC = (255, 255, 255) # ui inputs text color

uiPRW = width // 1.5 # ui project rect width
uiPRH = height // 10 # ui project rect height
uiBS = width // 8 if height > 720 else width // 18  # ui buttons size
uiBFS = 1 # ui button font size
uiIW = width // 2 # ui input width
uiIH = uiIW // 4 if height >= width else uiIW // 10 # ui input height
uiSOCP = 10 # start object components pos
uiWBBR = 15 # widgets buttons border radius
uiWIBR = 15 # widgets inputs, toggle buttons border radius
uiWPEOEEBR = 15 # widgets project elements, object hierarchy elements border radius
uiPMFS = 0 # project manager fill size
uiSOHFL = 0 #  ui selection object hierarchy fill size
uiISIOISV = 128 # image size in object inspector, small version
uiISIOIBV = 256 # image size in object inspector, big version

config_name = "dark" # config name
load_config = False # if true it will load the config file from root folder

if load_config:
    try:
        with open(f"configs/{config_name}.txt", "r") as config:
            get = config.read().split("\n")
                    
            for obj in get:
                sbr = obj.split("=", 1)
                if len(sbr) > 1 and sbr[0][0] != "#":
                    exec(f"{sbr[0].strip()} = {sbr[1].strip()}")
    except: pass