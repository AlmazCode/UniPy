import pygame, re
import UniPy as pe
import settings as st

class Text:
    def __init__(self, surface: pygame.Surface, x: int, y: int, text: str, fs: int, font: str, color: tuple, tsp: int, a: int, r: int, fx: bool, fy: bool, cx: str, cy: str, sx: int, sy: int, sfs: int, tc: str, rt):
        self.win = surface
        
        self.factor = min(surface.get_width() / st.projectSize[1], surface.get_height() / st.projectSize[0]) if surface.get_width() != st.projectSize[0] and surface.get_height() != st.projectSize[1] else 1
        
        self.x = int(sx * self.factor)
        self.y = int(sy * self.factor)
        self.oldX, self.oldY = x, y
        
        self._text = text
        self._fontSize = int(sfs * self.factor)
        self._sfs = sfs
        self.fontPath = font
        self.richText = True if rt == 1 else False
        
        try: self._font = pygame.font.Font(font, self._fontSize) if font != "None" else pygame.font.Font(None, self.fontSize)
        except: self._font = pygame.font.Font(None, self._fontSize)
        
        GC = color.split(" ")
        self.color = (int(GC[0]), int(GC[1]), int(GC[2]))
        self.transparent = tsp
        
        self.flipX = False if fx == 0 else True
        self.flipY = False if fy == 0 else True
        
        self._sx = sx
        self._sy = sy
        
        self.cx = cx
        self.cy = cy
        
        self.textCentering = tc if tc in ["left", "center", "right"] else "left"
        
        self.render = True if r == 1 else False
        self.angle = a
        
        self.compileText()
        
        self.width, self.height = self.textes[0].get_size()
    
    def compileText(self):
        self.textes = []
        
        if self.richText:
            lastColor = self.color
            for TEXT in str(self.text).split("\\n"):
                
                color_pattern = re.compile(r'\(\$?(\d+),\$?(\d+),\$?(\d+)\)')
                TEXT = re.sub(color_pattern, r'(\1, \2, \3)', TEXT)
                color_tags = re.findall(r"\(\s*\d+\s*,\s*\d+\s*,\s*\d+\s*\)", TEXT)
                
                i = 0
                substrings = []
                stack = [lastColor]
                
                while i < len(TEXT):
                    char = TEXT[i]
                    if len(TEXT) > 1 and char == "$" and TEXT[i+1] == "(":
                        if color_tags:
                            color = tuple(map(int, color_tags.pop(0)[1:-1].split(",")))
                            stack.append(color)
                            lastColor = color
                            
                            i += len(str(color)) + 1
                        else:
                            if substrings != []: substrings[-1][0] += "$"
                            else:
                                substrings.append(["$", self.color])
                            i += 1
                            stack.append(lastColor)
                    else:
                        j = i + 1
                        while j < len(TEXT) and TEXT[j] != "$": j += 1
                        substr = TEXT[i:j]
                        substrings.append([substr, stack[-1]])
                        i = j
                
                x = 0
                surf = pygame.Surface(self.font.size("".join(item[0] for item in substrings)))
                surf.fill((1, 1, 1))
                for subr, color in substrings:
                    tx = self.font.render(subr, 0, color)
                    surf.blit(tx, (x, 0))
                    x += tx.get_width()
                
                surf.set_colorkey((1, 1, 1))
                self.textes.append(surf)
        
        else:
            for i in str(self.text).split("\\n"):
                tx = self.font.render(i, 0, self.color)
                self.textes.append(tx)
        
        self.overallHeight = sum(sublist.get_height() for sublist in self.textes)
    
    @property
    def fontSize(self):
        return self._fontSize
    
    @property
    def font(self):
        return self._font
    
    @property
    def text(self):
        return self._text
    
    @property
    def sx(self):
        return self._sx
    @property
    def sy(self):
        return self._sy
    
    @property
    def sfs(self):
        return self._sfs
    
    @sx.setter
    def sx(self, value):
        self._sx = value
        self.x = int(self._sx * self.factor)
    
    @sy.setter
    def sy(self, value):
        self._sy = value
        self.y = int(self._sy * self.factor)
    
    @fontSize.setter
    def fontSize(self, value):
        self._fontSize = value
        self._font = pygame.font.Font(self.fontPath, self._fontSize) if self.fontPath != "None" else pygame.font.Font(None, self._fontSize)
        
        self.compileText()
        
        self.setPos()
        self.setPosObject()
    
    @sfs.setter
    def sfs(self, value):
        self._sfs = value
        self._fontSize = int(self._sfs * self.factor)
        self._font = pygame.font.Font(self.fontPath, self._fontSize) if self.fontPath != "None" else pygame.font.Font(None, self._fontSize)
    
    @font.setter
    def font(self, value):
        self._font = pygame.font.Font(value, self._fontSize)
        self.fontPath = value
        
        self.compileText()
        
        self.setPos()
        self.setPosObject()
    
    @text.setter
    def text(self, value):
        self._text = value
        self.compileText()
        self.setPos()
        self.setPosObject()
    
    def setPosObject(self):
        
        if self.cx[:4] == "objX" and self.cx[4] == "(" and self.cx[-1] == ")":
            if self.cx[5:-1] in pe.objName:
            	self.x = int(self._sx * self.factor)
            	self.x = pe.GetObj(self.cx[5:-1]).x + self.x
        
        elif self.cx[:5] == "objCX" and self.cx[5] == "(" and self.cx[-1] == ")":
            if self.cx[6:-1] in pe.objName:
            	self.x = int(self._sx * self.factor)
            	self.x = pe.GetObj(self.cx[6:-1]).rect.centerx - self.width // 2
        
        if self.cy[:4] == "objY" and self.cy[4] == "(" and self.cy[-1] == ")":
            if self.cy[5:-1] in pe.objName:
            	self.y = int(self._sy * self.factor)
            	self.y = pe.GetObj(self.cy[5:-1]).y + self.y
        
        elif self.cy[:5] == "objCY" and self.cy[5] == "(" and self.cy[-1] == ")":
            if self.cy[6:-1] in pe.objName:
            	self.y = int(self._sy * self.factor)
            	self.y = pe.GetObj(self.cy[6:-1]).rect.centery - self.overallHeight // 2
    
    def setPos(self):
        self.width, self.height = self.textes[0].get_size()
        
        if self.cx == "right": self.x = self.win.get_width() - self.width + self._sx
            
        elif self.cx == "center": self.x = self.win.get_width() // 2 - self.width // 2 + self._sx
            
        if self.cy == "bottom": self.y = self.win.get_height() - self.overallHeight + self._sy
        
        elif self.cy == "center": self.y = self.win.get_height() // 2 - self.overallHeight  // 2 + self._sy
    
    def update(self):
        if self.render:
            y = 0
            
            firstText = self.textes[0]
            for text in self.textes:

                endText = text
                if self.angle != 0: endText = pygame.transform.rotate(endText, self.angle)
                endText = pygame.transform.flip(endText, self.flipX, self.flipY)
                if self.transparent != 255: endText.set_alpha(self.transparent)
                if self.textCentering == "center" and y != 0: pos = endText.get_rect(center = (self.x + firstText.get_width() // 2, 0))
                elif self.textCentering == "left": pos = (self.x, self.y)
                elif self.textCentering == "right": pos = endText.get_rect(right = self.x + firstText.get_width())
                else: pos = (self.x, self.y)
                
                self.win.blit(endText, (pos[0], self.y + y))
                y += text.get_height()
                lastText = endText