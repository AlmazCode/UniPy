import UniPy as up
import re

tx = up.GetObj("code")
up.SetBgColor((40, 44, 52))

# определение цветов для разных типов токенов
colors = {
    "comment": (170, 170, 170),
    "string": (46, 204, 64),
    "keyword": (177, 13, 201),
    "function": (0, 116, 217),
    "number": (255, 215, 0),
    "operator": (255, 255, 255)
}

funcs = ["print", "input", "range"]
keywords = ["if", "else", "elif", "while", "for", "in", "break", "continue", "import", "from"]

# шаблоны для каждого типа токена
patterns = [
    (re.compile(r'"""(?:\\.|[^"\\])*"""|#[^\n]*\n?(?:#[^\n]*\n?)*'), "comment"),  # комментарии
    (re.compile(r'"(?:\\.|[^"\\])*"'), "string"),  # строки
    (re.compile(r'\b(?:' + '|'.join(funcs) + r')\b'), "function"),  # функции
    (re.compile(r'\b(?:' + '|'.join(keywords) + r')\b'), "keyword"),  # ключевые слова
    (re.compile(r'\b\d+\b'), "number"),  # числа
    (re.compile(r'[-+*/%=<>(){}[\]]'), "operator")  # операторы
]

# функция для лексического анализа текста
def lex(text):
    tokens = []
    pos = 0
    while pos < len(text):
        match = None
        for pattern, tag in patterns:
            match = pattern.match(text, pos)
            if match:
                tokens.append((match.group(), colors[tag]))
                pos = match.end()
                break
        if not match:
            tokens.append((text[pos], colors["operator"]))
            pos += 1
    return tokens


code = """import time

# infinity loop
while 1:
    print("UniPy!")"""

tokens = lex(code)
up.consoleLog("".join([f"${i[1]}{i[0]}" for i in tokens]))
tx.text = "".join([f"${i[1]}{i[0]}" for i in tokens]).replace("\n", "\\n")