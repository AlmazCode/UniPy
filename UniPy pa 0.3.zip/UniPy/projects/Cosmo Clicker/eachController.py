import UniPy as up

earch = up.GetObj("earch")
angle = 0
gm = None

def Click():
    earch.width -= 10
    earch.height -= 10
    earch.setPos()
    gm.onClick()

def unClick():
    earch.width += 10
    earch.height += 10
    earch.setPos()

def Start():
	global gm
	
	gm = up.GetModule("gameController")

def Update():
    global angle
    
    earch.angle = angle
    earch.setPos()
    angle += 1

earch.onPressed = Click
earch.onUnPressed = unClick