import UniPy as up
import random

up.SetBgColor((20, 20, 20))

txPeoples = up.GetObj("peoples")
imgPeoples = up.GetObj ("people_img")
btShop = up.GetObj("btShop")
btClose = up.GetObj("btClose")
earch = up.GetObj("earch")
stars = up.GetObj("stars")

peoples = up.LoadVariable("peoples", 0)
time = 0
endTime = random.randint(1, 5) * 60

txPeoples.text = str(peoples)

def onClick():
    global peoples
    
    peoples += 1
    up.SaveVariable("peoples", peoples, "int")
    txPeoples.text = str(peoples)
    imgPeoples.setPosObject()

def toShop():
    btShop.render = False
    stars.render = False
    txPeoples.render = False
    imgPeoples.render = False
    earch.render = False
    btClose.render = True

def toLobby():
    btShop.render = True
    stars.render = True
    txPeoples.render = True
    imgPeoples.render = True
    earch.render = True
    btClose.render = False

def Update():
    global time, endTime, peoples
    
    time += 1
    
    if time == endTime:
        peoples += random.randint(1, 20)
        up.SaveVariable("peoples", peoples, "int")
        time = 0
        endTime = random.randint(1, 5) * 60
        txPeoples.text = str(peoples)
        imgPeoples.setPosObject()

btShop.onPressed = toShop
btClose.onPressed = toLobby